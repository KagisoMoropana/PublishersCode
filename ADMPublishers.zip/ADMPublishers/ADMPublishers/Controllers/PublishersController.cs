﻿using ADMPublishers.DataAccess;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADMPublishers.Controllers
{
    public class PublishersController : Controller
    {
        PublisherContext Db { get; set; }
        public PublishersController(PublisherContext db)
        {
            Db = db;
        }
        [HttpGet]
        public ActionResult CaptureAuthor()//loads page to capture author
        {
            Authors author = new Authors();
            return View(author);
        }
        [HttpPost]
        public ActionResult CaptureAuthor(Authors model) // post author details after capturing
        {
            try
            {
                if (!ModelState.IsValid)
                    return View();
                
                Db.Authors.Add(model);
                Db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception )
            {
                return View();

            }
        }
        [HttpGet]
        public ActionResult Edit(string AuthorId)// loads page to edit/update author details
        {
            var author = Db.Authors.Find(AuthorId);
            return View(author);
        }
        [HttpPost]
        public ActionResult Edit(Authors model)// commits author details updates
        {
            if (!ModelState.IsValid) return View(model);
            try
            {
                Db.Authors.Update(model);
                Db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception )
            {
                return View();
            }
        }

        [HttpGet]
        public ActionResult Delete(string AuthorId)//loads delete page to delete author record
        {
            var author = Db.Authors.Find(AuthorId);
            return View(author);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmation(string AuthorId, Authors author) //commits the delete in the database
        {
            var target = Db.Authors.Find(AuthorId);
            Db.Remove(target);
            Db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Index()//Loads list of authors
        {
            var authors = Db.Authors.ToList();
            return View(authors);
        }

       
    }
}
